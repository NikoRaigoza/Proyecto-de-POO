package proyectoPOO.PuntodeVenta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PuntodeVentaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PuntodeVentaApplication.class, args);
	}

}
